import { Injectable } from '@angular/core';
import { ILoginResult } from '../shared/interfaces/login-result.interface';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  login(username: string, password: string): Promise<ILoginResult> {
    return new Promise<ILoginResult>((resolve, reject) => {
      setTimeout(() => {
        console.log('Login attempt with:', username, password);
        const loginSuccessful = username === password; 
        if (loginSuccessful) {
          resolve({ loginSuccessful: true });
        } else {
          resolve({ loginSuccessful: false });
        }
      }, 1000); 
    });
  }
  logout(): void {
    console.log('Logged out');
  }
}
