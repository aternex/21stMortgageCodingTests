import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { ILoginResult } from '../shared/interfaces/login-result.interface';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  loginResultMessage: string = '';
  loginProcessing: boolean = false;

  constructor(private fb: FormBuilder, private loginService: LoginService) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(16)]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(64)]]
    });
  }

  onLogin(): void {
    if (this.loginForm.valid) {
      this.loginResultMessage = '';
      this.loginProcessing = true;

      this.loginService.login(this.loginForm.value.username, this.loginForm.value.password)
        .then((result: ILoginResult) => {
          this.loginResultMessage = result.loginSuccessful ? 'Result: Login successful!' : 'Result: Login failed!';
          this.loginProcessing = false;
        })
        .catch((error: any) => {
          this.loginResultMessage = 'Error: ' + (error.message || JSON.stringify(error));
          this.loginProcessing = false;
        });
    } else {
      this.loginProcessing = false;

      Object.keys(this.loginForm.controls).forEach(field => {
        const control = this.loginForm.get(field);
        control?.markAsTouched({ onlySelf: true });
      });
    }
  }

  getErrorMessage(controlName: string): string {
    const control = this.loginForm.get(controlName);
    if (control?.hasError('required')) {
      return 'You must enter a value for ' + controlName;
    }

    if (control?.hasError('minlength')) {
      return  controlName + ' must be at least ' + control.errors?.minlength.requiredLength + ' characters long';
    }

    if (control?.hasError('maxlength')) {
      return controlName + ' must be ' + control.errors?.maxlength.requiredLength + ' or less';
    }

    return '';
  }
}
