﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;

namespace _21stMortgageInterviewApplication.Domain.ViewModels
{
    public class FauxViewModel : INotifyPropertyChanged
    {
        private string _userInput;
        private string _result;
        private int _numberSign;

        public string UserInput
        {
            get => _userInput;
            set
            {
                _userInput = value;
                OnPropertyChanged(nameof(UserInput));
            }
        }

        public string Result
        {
            get => _result;
            set
            {
                _result = value;
                OnPropertyChanged(nameof(Result));
            }
        }

        public int NumberSign
        {
            get => _numberSign;
            set
            {
                _numberSign = value;
                OnPropertyChanged(nameof(NumberSign));
            }
        }

        public ICommand FindLargestCommand { get; }
        public ICommand FindSumOddNumbersCommand { get; }
        public ICommand FindSumEvenNumbersCommand { get; }

        public event PropertyChangedEventHandler PropertyChanged;

        public FauxViewModel()
        {
            FindLargestCommand = new RelayCommand(param => FindLargest());
            FindSumOddNumbersCommand = new RelayCommand(param => FindSumOddNumbers());
            FindSumEvenNumbersCommand = new RelayCommand(param => FindSumEvenNumbers());
        }

        private int[] ParseNumbers()
        {
            ReadOnlySpan<char> inputSpan = UserInput.AsSpan();
            List<int> numbers = new List<int>();

            int lastComma = -1;
            for (int i = 0; i <= inputSpan.Length; i++)
            {
                if (i == inputSpan.Length || inputSpan[i] == ',')
                {
                    if (int.TryParse(inputSpan.Slice(lastComma + 1, i - lastComma - 1), out int num))
                    {
                        numbers.Add(num);
                    }
                    lastComma = i;
                }
            }

            return numbers.ToArray();
        }

        private void SetResult(long? num)
        {
            Result = num.HasValue ? num.Value.ToString() : "Invalid input received.";
            SetNumberSign(num);
        }

        private void SetNumberSign(long? num)
        {
            NumberSign = num.HasValue ? (num.Value > 0 ? 1 : num.Value < 0 ? -1 : 0) : 0;
        }

        private void FindLargest()
        {
            int[] numbers = ParseNumbers();
            SetResult(numbers.Length != 0 ? numbers.Max() : null);
        }

        private long Sum(IEnumerable<int> numbers)
        {
            return numbers.Sum(x => (long)x);
        }

        private void FindSumOddNumbers()
        {
            int[] numbers = ParseNumbers();
            SetResult(numbers.Length != 0 ? Sum(numbers.Where(x => Math.Abs(x % 2) == 1)) : 0);
        }

        private void FindSumEvenNumbers()
        {
            int[] numbers = ParseNumbers();
            SetResult(numbers.Length != 0 ? Sum(numbers.Where(x => x % 2 == 0)) : 0);
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}